﻿document.addEventListener("DOMContentLoaded", function () {
    var table = document.getElementById('sortedTable');
    var ths = table.getElementsByTagName('th');

    var sortDirections = {}; // Obiekt przechowujący kierunki sortowania dla poszczególnych kolumn

    // Ustaw domyślne sortowanie na ID w kolejności rosnącej
    sortTable('Id', 'asc');

    Array.from(ths).forEach(function (th) {
        th.addEventListener('click', function () {
            var sort = th.getAttribute('data-sort');
            sortTable(sort);
        });
    });

    function sortTable(sort, direction) {
        console.log('Sortowanie wg kolumny:', sort);
        console.log('Kierunek sortowania:', direction);
        var tbody = table.getElementsByTagName('tbody')[0];
        var rows = tbody.getElementsByTagName('tr');
        var sortedRows = Array.from(rows).sort(function (a, b) {
            var aValue = a.querySelector('td[data-sort="' + sort + '"]').innerText;
            var bValue = b.querySelector('td[data-sort="' + sort + '"]').innerText;
            return aValue.localeCompare(bValue, undefined, { numeric: true });
        });

        // Sprawdź kierunek sortowania i ustaw go na przeciwny, jeśli nie podano
        if (!direction) {
            direction = sortDirections[sort] === 'asc' ? 'desc' : 'asc';
        }

        // Zapisz kierunek sortowania dla danej kolumny
        sortDirections[sort] = direction;

        // Odwróć kolejność, jeśli sortowanie jest malejące
        if (direction === 'desc') {
            sortedRows.reverse();
        }

        while (tbody.firstChild) {
            tbody.removeChild(tbody.firstChild);
        }

        sortedRows.forEach(function (row) {
            tbody.appendChild(row);
        });

        // Usuń strzałki sortowania ze wszystkich nagłówków
        Array.from(ths).forEach(function (th) {
            th.innerHTML = th.innerHTML.replace(/ ▲| ▼/, '');
        });

        // Dodaj strzałkę sortowania do sortowanego nagłówka
        var sortIcon = direction === 'asc' ? ' ▲' : ' ▼';
        document.querySelector('th[data-sort="' + sort + '"]').innerHTML += sortIcon;
    }
});
