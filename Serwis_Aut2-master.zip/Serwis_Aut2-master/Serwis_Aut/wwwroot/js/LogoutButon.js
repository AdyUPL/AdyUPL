﻿document.getElementById("logout").addEventListener("click", function (e) {
    e.preventDefault();
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    fetch('/Account/Logout', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'RequestVerificationToken': csrfToken
        }
    }).then(function (response) {
        if (response.ok) {
            window.location.href = '/Home/Index';
        } else {
            console.error('Logout failed:', response.statusText);
        }
    }).catch(function (error) {
        console.error('Logout error:', error);
    });
});