// script.js
document.addEventListener("DOMContentLoaded", function() {
    const logoutLink = document.querySelector("a[href='#'][span='Wyloguj']");
    const changePasswordLink = document.querySelector("a[href='#'][span='Zmień Hasło']");

    if (logoutLink) {
        logoutLink.addEventListener("click", function(event) {
            event.preventDefault();
            // Tutaj dodaj logikę wylogowania użytkownika
            alert("Zostałeś wylogowany.");
        });
    }

    if (changePasswordLink) {
        changePasswordLink.addEventListener("click", function(event) {
            event.preventDefault();
            // Tutaj dodaj logikę zmiany hasła
            alert("Funkcja zmiany hasła jest w trakcie implementacji.");
        });
    }
});
