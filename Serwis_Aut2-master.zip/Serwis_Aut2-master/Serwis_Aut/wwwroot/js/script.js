// Tworzenie nowej instancji obiektu FormValidator i przypisanie jej do stałej formValidator
//const formValidator = new FormValidator();


document.addEventListener('DOMContentLoaded', function () {
    var selectElement = document.getElementById('showOld');
    if (selectElement != null)
    {
        var urlParams = new URLSearchParams(window.location.search);
        var old = urlParams.get('showOld');

        // Set the selected option based on the URL parameter
        if (old) {
            selectElement.value = old;
        } else {
            selectElement.value = "false";
        }

        // Add event listener for change event to update URL
        selectElement.addEventListener('change', function () {
            var selectedOld = this.value;
            var url = new URL(window.location.href);
            if (selectedOld) {
                url.searchParams.set('showOld', selectedOld);
            } else {
                url.searchParams.delete('showOld');
            }
            window.location.href = url.toString();
        });
    }

 });
