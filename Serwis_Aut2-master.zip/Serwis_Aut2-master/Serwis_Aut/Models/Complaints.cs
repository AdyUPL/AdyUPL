﻿
using System.CodeDom;
using System.ComponentModel.DataAnnotations;

namespace Serwis_Aut.Models
{
    public class Complaints{
        [Key]
        public int ID {get; set;}
        public int userID { get; set;}
        public int serviceID {get; set;}
        public string comment { get; set;}
        public int statusID {get; set;}
        public DateTime? addDate {get; set;}
        public DateTime? closeDate {get; set;}
        public DateTime? lastDate {get; set;}

    }

    public class ComplaintsView
    {
        [Key]
        public int comID { get; set; }
        public int serviceID { get; set; }
        public int userID { get; set; }
        public DateTime? comAddDate { get; set; }
        public DateTime? comCloseDate { get; set; }
        public DateTime? comLastDate { get; set; }
        public string? comComment { get; set; }
        public string? userName { get; set; }
        public string? userCompName { get; set; }
        public string? userContact { get; set; }
        public string? userContact2 { get; set; }
        public int? comStatusID { get; set; }
        public string? comStatusName { get; set; }
    }
    public class ComplaintsChat
    {
        [Key]
        public int? ID {get; set;}
        public int? complaintID {get; set;}
        public int? userID {get; set;}
        public string? comment {get; set;}
        public DateTime? addDate {get; set;}
    }
    public class ComplaintsChat2 : ComplaintsChat
    {
        public string? UserName { get; set; }
        public int? UserLevel { get; set; }

    }

    public class ComplaintsFull : ComplaintsView
    {
        public List<ComplaintsChat2>? Chat {  get; set;}
        
    }
}
