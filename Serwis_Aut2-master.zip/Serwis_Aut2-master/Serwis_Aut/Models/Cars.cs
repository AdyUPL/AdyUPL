﻿
using System.ComponentModel.DataAnnotations;

namespace Serwis_Aut.Models
{
    public class Cars{ 
        public int ID { get; set; }

        public int userID { get; set; }
        [Required(ErrorMessage = "Marka auta jest wymagana.")]
        public string? brand { get; set; }
        [Required(ErrorMessage = "Model auta jest wymagany.")]
        public string? model { get; set; }
        [Required(ErrorMessage = "Numer rejestracyjny jest wymagany.")]
        public string? registerplate { get; set; }
        public bool deleted {  get; set; }
    }

    public class CarSelector
    {
        public int ID { get; set; }
        public int userID { get; set; }
        public string Name { get; set; }
    }

}
