﻿using Microsoft.AspNetCore.Identity;
using NuGet.Packaging.Signing;
namespace Serwis_Aut.Models
{
    public class Categories
    {
        public int ID { get; set; }
        public string? Name { get; set; }
        public string? Selector { get; set; }
    }

}
