﻿using Microsoft.AspNetCore.Identity;
using Microsoft.CodeAnalysis;
using NuGet.Packaging.Signing;
using System.ComponentModel.DataAnnotations;
namespace Serwis_Aut.Models
{
    public class DocType
    {
        public int ID { get; set; }
        public string? Name { get; set; }
        public string? Short { get; set; }
    }
    public class DocItems
    {
        public int? ID { get; set; } // ID rekordu
        public int docID {  get; set; } // Numer iD dokumentu do powiązania
        public int itemID {  get; set; } // numer ID przedmiotu na potrzeby nazw cen itp.
        public int amount { get; set; } // ilość danego przedmiotu

    }
    public class DocItemsList : DocItems
    {
        public int Count { get; set; }  // na potrzeby numeracji
        public string? itemName { get; set; } // nmazwa
        public string? itemUnit { get; set; } // jednostka miary szt. / worki itp.
        public double itemUnitPrice { get; set; } // kwota za 1 zł netto
        public double itemUnitPriceBR { get; set; } // kwota za 1 zł brutto
        public double allItemsPrice { get; set; } // suma netto jednego itemu
        public double allItemsPriceBR { get; set; } // suma brutto jednego itemu
        public double costVat { get; set; } // suma VAT
        

    }


    public class Docs
    {
        public int ID { get; set; }// id dokumentu
        public string? fullNumber { get; set; }// pelny numer
        public int? userID { get; set; }// id usera
        public int? workerID { get; set; }// id wystawcy
        public DateTime? addDate { get; set; }// data wystawienia
        public DateTime? sellDate { get; set; }// data zakupu
        public string? description { get; set; }// dodatkowy opis
        public int? ownID { get; set; }// wlasne id na potrzeby prawidlowego numerowania
        public int? docType { get; set; } // typ dokumentu na potrzeby prawidlowych nazw
        public string? payMethod { get; set; }
        public int? serviceID {  get; set; }
    }

    
    public class DocsFullNameModel : Docs
    {
       // public DocumentModel docs { get; set; }
        public string? userName { get; set;} // nazwa usera
        public string? workerName { get; set; } // nazwa wystawcy
        public List<DocItemsList>? Items { get; set; }
        public double costNetto {  get; set; } // suma netto
        public double costBR { get; set; } // suma wartosci brutto - 
        public double costVAT { get; set; }  // suma kwoty brutto
        public string? companyName {  get; set; }
        public string? companyAddress { get; set; }
        public string? companyPostCity { get; set; }
        public string? companyNIP { get; set; }
    }


}
