﻿using Microsoft.AspNetCore.Identity;
using NuGet.Packaging.Signing;
using System.ComponentModel.DataAnnotations;

namespace Serwis_Aut.Models
{
    public class Orders
    {
        public int ID { get; set; }
        public int? UserID { get; set; }
        public int? ItemID { get; set; }
        public int? StatusID { get; set; }
        public int? Amount { get; set; }
    }

    public class OrdersView
    {
        [Key]
        public int ID { get; set; }
        public int? UserID { get; set; }
        public int? ItemID { get; set; }
        public int? StatusID { get; set; }
        public int? Amount { get; set; }
        public string? UserName { get; set; }
        public string? ItemName { get; set; }
        public string? Status { get; set; }
    }

}
