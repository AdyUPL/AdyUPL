﻿using Microsoft.AspNetCore.Identity;
using NuGet.Packaging.Signing;
using System.ComponentModel.DataAnnotations;
namespace Serwis_Aut.Models
{
    public class Service
    {
        public int ID { get; set; }
        public int userID { get; set; }
        public int? workerID { get; set; }
        public int? docID { get; set; }
        public int carID { get; set; }
        public string? description { get; set; }
        public int statusID { get; set; }
        public DateTime addDate { get; set; }
        public DateTime? serviceDate { get; set; }
    }
    public class ServiceUserViewModel
    {
        public int? id { get; set; }
        public string? auto { get; set; }
        public int? userID { get; set; }
        public string? opis { get; set; }
        public string? status { get; set; }
        public int? statusID { get; set; }
        public DateTime addDate { get; set; }
        public int? docID { get; set; }
        public string? docFullName { get; set; }
        public DateTime? serviceDate { get; set; }
        public int? workerID { get; set; }
        public int? complaintID { get; set; }
        public int? complaintStatus { get; set; }
    }


    public class FullServiceInfo
    {
       [Key]
       public int ID { get; set; }
       public string? Status { get; set; }
       public string? UserName { get; set; }
       public string? UserCompany { get; set; }
       public string? UserCompanyAddress { get; set; }
       public string? UserCompanyNIP { get; set; }
       public string? UserCompanyPost { get; set; }
       public string? UserEmail { get; set; }
       public string? UserPhone { get; set; }
       public string? WorkerName { get; set; }
       public string? CarBrand { get; set; }
       public string? CarModel { get; set; }
       public string? CarPlate { get; set; }
       public string? ServiceDesc { get; set; }
       public DateTime? ServiceAddDate { get; set; }
       public DateTime? ServiceDate { get; set; }
       public string? DocFullNumber { get; set; }
       public DateTime? DocAddDate { get; set; }
       public DateTime? DocSellDate { get; set; }
       public string? DocDesc { get; set; }
       public string? DocType { get; set; }
       public string? DocTypeShort { get; set; }
       public string? PayMethod { get; set; }
       public int? UserID { get; set; }
       public int? WorkerID { get; set; }
       public int? CarID { get; set; }
       public int? DocID { get; set; }
       public int? DocTypeID { get; set; }

    }

    public class ServiceFullViewPage : FullServiceInfo
    {
        public List<DocItemsList> Items { get; set; }
        public double sumNetto { get; set; }
        public double sumBrutto { get; set;}
        public double sumVat { get; set; }
    }

}
