﻿using Microsoft.AspNetCore.Identity;
using NuGet.Packaging.Signing;
namespace Serwis_Aut.Models
{
    public class Storage
    {
        public int id { get; set; }
        public string? name { get; set; }
        public int? category { get; set; }
       public int amount { get; set; }
        public string? unit {  get; set; }
        public double unitPrice { get; set; }
    }
    public class StorageCat : Storage
    {
        public string? categoryName {  get; set; }
        public string? categorySelector { get; set; }
    }

    public class StorageSelector : StorageCat
    {
            public IEnumerable<Storage>? Items { get; set; } // Lista przedmiotów na potrzeby wyświetlania listy rozwijanej


    }

}
