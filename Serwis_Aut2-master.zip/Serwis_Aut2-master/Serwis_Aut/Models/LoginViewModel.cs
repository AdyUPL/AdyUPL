﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Serwis_Aut.Models
{
    public class LoginViewModel
    {
        [Required]
        public string login { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string password { get; set; }

/*        [Display(Name = "Zapamiętaj mnie")]
        public bool RememberMe { get; set; }*/
    }
}