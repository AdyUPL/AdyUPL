﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
namespace Serwis_Aut.Models
{
    public class Users{ 
        public int id { get; set; }
        public string login { get; set; }
        public string password { get; set; }
        public int level { get; set; }
        public string displayName { get; set; }
    }

    public class UsersLevel
    {
        public int id { get; set; }
        public string Name { get; set; }
    }

    public class UserLevelPermission
    {
        public int id { get; set; }
        public int lvlId { get; set; }
        public string pageName { get; set; }
        public bool granted { get; set; }
    }
    public class UserInfo
    {
        [Key]
        public int userid { get; set; }
        public string? companyName { get; set; } 
        public string? companyAddress { get; set; } 
        public string? companyNip { get; set; } 
        public string? companyPostCity { get; set; } 
        public string? contact { get; set; } 
        public string? contact2 { get; set; } 
    }
    public class UserInfoModel : UserInfo
    {
        public string? displayName { get; set; }
    }

    public class UserViewModel // Custom View dla wyświetlenia klilku tabel w jednej
    {
        public int Id { get; set; } // Users
        public string Name { get; set; } // Users
        public string Login { get; set; } // Users
        public string Password { get; set; } // Users
        public int Level { get; set; }  // Users 
        public string LevelName { get; set; } // UsersLevels
        // Później będą inne np . NIP, ADRES, itp z usersInfo
    }
}
