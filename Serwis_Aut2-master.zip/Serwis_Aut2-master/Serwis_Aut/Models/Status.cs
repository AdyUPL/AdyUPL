﻿using Microsoft.AspNetCore.Identity;
using NuGet.Packaging.Signing;
namespace Serwis_Aut.Models
{
    public class Status
    {
        public int id { get; set; }
        public int category { get; set; }
        public string? name { get; set; }
    }

}
