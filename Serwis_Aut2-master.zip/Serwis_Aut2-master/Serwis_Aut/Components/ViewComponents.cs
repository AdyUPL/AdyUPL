﻿using Microsoft.AspNetCore.Mvc;

namespace Serwis_Aut.ViewComponents
{
    public class NavBarViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View();
        }
    }
}
