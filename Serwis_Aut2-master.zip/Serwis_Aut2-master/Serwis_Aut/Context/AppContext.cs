﻿using Microsoft.EntityFrameworkCore;
using Serwis_Aut.Models;


namespace Serwis_Aut.Context
{
    public class myAppContext : DbContext
    {
        private readonly IConfiguration _configuration;

        public DbSet<Users> users { get; set; }
        public DbSet<UsersLevel> userslevels { get; set; }
        public DbSet<UserLevelPermission> userlevelspermission { get; set; }
        public DbSet<UserInfo> usersinfo { get; set; }
        public DbSet<Service> service { get; set; }
        public DbSet<FullServiceInfo> v_fullServiceInfo { get; set; }
        public DbSet<Status> status { get; set; }
        public DbSet<Categories> categories { get; set; }
        public DbSet<Complaints> complaints { get; set; }
        public DbSet<ComplaintsView> v_complaints { get; set; }
        public DbSet<ComplaintsChat> complaintschat { get; set; }
        public DbSet<DocType> docstype { get; set; }
        public DbSet<Docs> docs { get; set; }
        public DbSet<DocItems> docitems { get; set; }
        public DbSet<Cars> cars { get; set; }
        public DbSet<Storage> storage { get; set; }
        public DbSet<Orders> orders { get; set; }
        public DbSet<OrdersView> v_orders { get; set; }



        public myAppContext(DbContextOptions<myAppContext> options, IConfiguration configuration) : base(options)
        {
            _configuration = configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(_configuration.GetConnectionString("DefaultConnection"));
        }


    }
}