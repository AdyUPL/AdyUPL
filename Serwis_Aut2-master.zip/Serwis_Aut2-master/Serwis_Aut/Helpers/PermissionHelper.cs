﻿using Microsoft.EntityFrameworkCore;
using Serwis_Aut.Context;

namespace Serwis_Aut.Helpers
{
    public class PermissionHelper
    {
        private readonly myAppContext _context;

        public PermissionHelper(myAppContext context)
        {
            _context = context;
        }

        public async Task<bool> HasPermissionAsync(int userLevel, string pageName)
        {
            var permission = await _context.userlevelspermission
                .FirstOrDefaultAsync(p => p.lvlId == userLevel && p.pageName == pageName);

            return permission != null && permission.granted;
        }
        public bool HasPermission(int userLevel, string pageName)
        {
            var permission = _context.userlevelspermission
                .FirstOrDefaultAsync(p => p.lvlId == userLevel && p.pageName == pageName);

            return permission != null ? true : false;
        }
    }
}
