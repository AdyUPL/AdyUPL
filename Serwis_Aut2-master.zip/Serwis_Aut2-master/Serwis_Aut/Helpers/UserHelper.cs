﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Serwis_Aut.Helpers
{
    public static class UserHelper
    {
        public static int GetUserID(this ClaimsPrincipal user)
        {
            var userIDClaim = user.FindFirst("UserID")?.Value;
            if (userIDClaim != null)
            {
                return Int32.Parse(userIDClaim);
            }
            return 0; // Default level if not found or not an integer
        }
        public static int GetUserLevel(this ClaimsPrincipal user)
        {
            var userLevelClaim = user.FindFirst("UserLevel")?.Value;
            if (userLevelClaim != null && int.TryParse(userLevelClaim, out int userLevel))
            {
                return userLevel;
            }
            return 0; // Default level if not found or not an integer
        }
        public static string GetUserName(this ClaimsPrincipal user)
        {
            var userNameClaim = user.FindFirst("DisplayName")?.Value; 
            if (userNameClaim != null)
            {
                return userNameClaim;
            }
            return null; // Default level if not found or not an integer
        }
    }
}
