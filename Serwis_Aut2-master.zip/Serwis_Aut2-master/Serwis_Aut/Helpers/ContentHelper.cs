﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Serwis_Aut.Models;
using Serwis_Aut.Controllers;
using Serwis_Aut.Context;
using System.Security.Claims;
using System.Net.WebSockets;

namespace Serwis_Aut.Helpers
{

    public  class ContentHelper
    {
        private  readonly myAppContext _context;

        public void SetDateTimeKindToUtc(object entity)
        {
            var properties = entity.GetType().GetProperties()
                .Where(p => p.PropertyType == typeof(DateTime) || p.PropertyType == typeof(DateTime?));

            foreach (var property in properties)
            {
                if (property.PropertyType == typeof(DateTime))
                {
                    var date = (DateTime)property.GetValue(entity);
                    if (date.Kind == DateTimeKind.Unspecified)
                    {
                        property.SetValue(entity, DateTime.SpecifyKind(date, DateTimeKind.Utc));
                    }
                }
                else if (property.PropertyType == typeof(DateTime?))
                {
                    var date = (DateTime?)property.GetValue(entity);
                    if (date.HasValue && date.Value.Kind == DateTimeKind.Unspecified)
                    {
                        property.SetValue(entity, (DateTime?)DateTime.SpecifyKind(date.Value, DateTimeKind.Utc));
                    }
                }
            }
        }

        // Na kiedyś ( pokazywać ma ilość nowych zgłoszeń itp. ) dla serwisu
        public async void countNewItems(string content)
        {
            int result = 0;
            switch (content)
            {
                case "service":
                    var serviceCount =   await _context.service.CountAsync(x => x.statusID == 0);
                    result = serviceCount;
                    break;
                case "complaints":
                    var complaintsCount = await _context.complaints.CountAsync(x => x.statusID == 4 || x.statusID == 6);
                    result = complaintsCount;
                    break;
                default:
                    Console.WriteLine($"\n\nBŁĄD: Podano nieprzypisaną zmienną -> {content}");
                    break;
            }
        }

        public string ShowModal(string header,string content)
        {
            var stringBuilder = "<div id=\"ModalMsg\" class=\"modal\" tabindex=\"-1\">" +
                                "<div class=\"modal-dialog modal-dialog-centered\">" +
                                "<div class=\"modal-content\">" +
                                "<div class=\"modal-header\">" +
                                $"<h5 class=\"modal-title w-100\">{header}</h5>" +
                                "<button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>" +
                                "</div>" +
                                "<div class=\"modal-body\">" +
                                $"{content}" +
                                "</div></div></div></div>";

            var script = "<script type=\"text/javascript\">" +
                         "$(window).on('load', function() {" +
                         "$('#ModalMsg').modal('show');" +
                         "});" +
                         "</script>";
            return stringBuilder + script;
        }

    }
}
