using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Serwis_Aut.Context;
using Serwis_Aut.Models;
using Microsoft.AspNetCore.Mvc;
using Serwis_Aut.Helpers;
namespace Serwis_Aut
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Dodaj IHttpContextAccessor
            builder.Services.AddHttpContextAccessor();

            // Pobierz po��czenie z pliku appsettings.json
            string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

            // Dodaj DbContext i konfiguracj� Identity
            builder.Services.AddDbContext<myAppContext>(options =>
                options.UseNpgsql(connectionString));

            builder.Services.AddScoped<PermissionHelper>(); // Dodanie obs�ugi tabeli permissi
            builder.Services.AddTransient<ContentHelper>();

            builder.Services.AddAntiforgery(options =>
            {
                options.HeaderName = "RequestVerificationToken";
            });

            builder.Services.AddDistributedMemoryCache();
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });

            builder.Services.AddAuthentication("SerwisAut")
               .AddCookie("SerwisAut", options =>
               {
                   options.Cookie.Name = "SerwisAut"; // nazwa ciasteczka uwierzytelniania
                   options.LoginPath = "/Account/Login"; // �cie�ka zapisu ciasteczka
                   options.LogoutPath = "/Account/Logout";
                   options.SlidingExpiration = true; // od�wie�a ciasteczko przy aktywno�ci

               });

            builder.Services.AddControllersWithViews(options =>
            {
                options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
            });
            var app = builder.Build();

            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Shared/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
                // endpoints.MapRazorPages();

            });

            app.Run();
        }
    }
}
