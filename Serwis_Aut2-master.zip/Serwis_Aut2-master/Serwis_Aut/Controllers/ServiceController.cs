﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Serwis_Aut.Context;
using Serwis_Aut.Models;
using Serwis_Aut.Helpers;
using System.Runtime.InteropServices.JavaScript;
using System.Xml;
using Microsoft.CodeAnalysis.Scripting;

namespace Serwis_Aut.Controllers
{
    public class ServiceController : Controller
    {
        private readonly myAppContext _context;
        private readonly ILogger<ServiceController> _logger;
        private readonly IConfiguration _configuration;
        private readonly PermissionHelper _permissionHelper;
        private readonly ContentHelper _helper;

        public ServiceController(myAppContext context, ILogger<ServiceController> logger, IConfiguration configuration, PermissionHelper permissionHelper, ContentHelper helper)
        {
            _configuration = configuration;
            _logger = logger;
            _context = context;
            _helper = helper;
            _permissionHelper = permissionHelper;
        }

        // #############################################
        // ################### INNE ####################
        // #############################################

        // Sprawdzanie uprawnień
        private async Task<bool> HasPermissions(string pageName)
        {
            int userLevel = User.GetUserLevel();
            bool perm = await _permissionHelper.HasPermissionAsync(userLevel, pageName);

            return perm || userLevel == -1;

        }
        // Pobieranie listy pozycji do dokumentu
        public List<DocItemsList> GetDocItems(int? docid)
        {

            var list = (from i in _context.docitems
                        join st in _context.storage on i.itemID equals st.id
                        where i.docID == docid
                        select new DocItemsList
                        {
                            ID = i.ID,
                            docID = i.docID,
                            itemID = i.itemID,
                            amount = i.amount,
                            itemName = st.name,
                            itemUnit = st.unit,
                            itemUnitPrice = st.unitPrice, // cena za 1 jm
                            itemUnitPriceBR = Math.Round(st.unitPrice * 1.23, 2), // cena brutto za 1 jm
                            allItemsPrice = st.unitPrice * i.amount, // suma  netto 
                            allItemsPriceBR = Math.Round(st.unitPrice * i.amount * 1.23, 2), //suma brutto
                            costVat = Math.Round(((st.unitPrice * 1.23) - st.unitPrice) * i.amount, 2) // suma br - suma netto

                        }).ToList();

            return list;
        }
        // Ustawienie czasu UTC dla funckji
        private void SetDateTimeKindToUtc(object entity)
        {
            var properties = entity.GetType().GetProperties()
                .Where(p => p.PropertyType == typeof(DateTime) || p.PropertyType == typeof(DateTime?));

            foreach (var property in properties)
            {
                if (property.PropertyType == typeof(DateTime))
                {
                    var date = (DateTime)property.GetValue(entity);
                    if (date.Kind == DateTimeKind.Unspecified)
                    {
                        property.SetValue(entity, DateTime.SpecifyKind(date, DateTimeKind.Utc));
                    }
                }
                else if (property.PropertyType == typeof(DateTime?))
                {
                    var date = (DateTime?)property.GetValue(entity);
                    if (date.HasValue && date.Value.Kind == DateTimeKind.Unspecified)
                    {
                        property.SetValue(entity, (DateTime?)DateTime.SpecifyKind(date.Value, DateTimeKind.Utc));
                    }
                }
            }
        }
        // #############################################
        // ############### WYŚWIETLANIE ################
        // #############################################

        // TERMINARZ
        public async Task<IActionResult> Index(bool showOld)
        {

            if (!HasPermissions("Service/ViewTermin").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var userServiceRequests = await(from s in _context.service
                                            join c in _context.cars on s.carID equals c.ID
                                            join st in _context.status on s.statusID equals st.id
                                            join d in _context.docs on s.docID equals d.ID into docsGroup
                                            from d in docsGroup.DefaultIfEmpty()
                                            select new ServiceUserViewModel
                                            {
                                                id = s.ID,
                                                auto = c.brand + " " + c.model,
                                                userID = s.userID,
                                                opis = s.description,
                                                status = st.name,
                                                statusID = st.id,
                                                addDate = s.addDate,
                                                docID = d != null ? d.ID : (int?)null,
                                                docFullName = d != null ? d.fullNumber : null,
                                                serviceDate = s!= null ? s.serviceDate : null,
                                                workerID = s != null ? s.workerID : (int?)null
                                            }).ToListAsync();

            
            if (showOld)
            {
                return View(userServiceRequests.Where(x=> x.statusID == 3));
            }
            else
            {
                return View(userServiceRequests.Where(x => x.statusID == 0));
            }
        }

        public IActionResult Error()
        {
            var errorViewModel = new ErrorViewModel();
            // Ustawianie właściwości errorViewModel, jeśli to konieczne
            return View(errorViewModel);
        }
        // WYŚWIETLENIE STRONY DO EDYCJI DLA SERWISU
        public async Task<IActionResult> EditService(int? id, ServiceFullViewPage model)
        {
            if (!HasPermissions("Service/EditServicePage").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            if (id != null)
            {
                // Itemy dla ViewBag.Items - Lista rozwijana przy dodawaniu
                var selector = await (from st in _context.storage
                                      join cat in _context.categories on st.category equals cat.ID
                                      where st.amount > 0
                                      select new StorageSelector
                                      {
                                          id = st.id,
                                          name = st.name,
                                          category = st.category, // assuming this is the category column
                                          categoryName = cat.Name, // assuming this is the category name column
                                          categorySelector = cat.Selector
                                      }).ToListAsync();


                var categories = selector
                .GroupBy(x => new { x.category, x.categoryName })
                .Select(g => g.First()).Where(x => x.categorySelector == "StorageItem")
                .ToList();

                ViewBag.Items = selector;
                ViewBag.Categories = categories;

                var docid = -1; // UJEMNA WARTOŚĆ DOMYŚLNIE ABY NA PEWNO NICZEGO NIE ZNALEŹĆ 
                var doc = await _context.docs.Where(x => x.serviceID == id).FirstOrDefaultAsync();

                if (doc != null)
                {
                    docid = doc.ID;

                }

                await Console.Out.WriteLineAsync($"DOC ID:{docid}");
                var docitemlist = GetDocItems(docid);

                double SumNetto = docitemlist.Sum(x => x.allItemsPrice);
                double SumBrutto = docitemlist.Sum(x => x.allItemsPriceBR);
                double sumVat = docitemlist.Sum(x => x.costVat);

                model = await (from s in _context.v_fullServiceInfo
                               where s.ID == id
                               select new ServiceFullViewPage
                               {
                                   ID = s.ID,
                                   Status = s.Status,
                                   UserName = s.UserName,
                                   UserCompany = s.UserCompany,
                                   UserCompanyAddress = s.UserCompanyAddress,
                                   UserCompanyNIP = s.UserCompanyNIP,
                                   UserCompanyPost = s.UserCompanyPost,
                                   UserEmail = s.UserEmail,
                                   UserID = s.UserID,
                                   UserPhone = s.UserPhone,
                                   WorkerID = s.WorkerID,
                                   WorkerName = s.WorkerName,
                                   CarBrand = s.CarBrand,
                                   CarID = s.CarID,
                                   CarModel = s.CarModel,
                                   CarPlate = s.CarPlate,
                                   DocAddDate = s.DocAddDate,
                                   DocDesc = s.DocDesc,
                                   DocFullNumber = s.DocFullNumber,
                                   ServiceAddDate = s.ServiceAddDate,
                                   ServiceDesc = s.ServiceDesc,
                                   ServiceDate = s != null ? s.ServiceDate : null,
                                   DocSellDate = s.DocSellDate,
                                   DocTypeShort = s.DocTypeShort,
                                   DocID = s.DocID,
                                   DocType = s.DocType,
                                   DocTypeID = s.DocTypeID,
                                   Items = docitemlist,
                                   PayMethod = s.PayMethod,
                                   sumBrutto = SumBrutto != null ? SumBrutto : 0,
                                   sumNetto = SumNetto != null ? SumNetto : 0,
                                   sumVat = sumVat != null ? sumVat : 0
                               }).FirstOrDefaultAsync();

                if (model != null)
                {
                    return View(model);
                }
                else
                {
                    return RedirectToAction("Index");
                }

            }
            else
            {
                return Error();
            }

        }

        // [W] TWORZENIE DOKUMENTU
        public async Task<IActionResult> AddDoc(int serviceid)
        {
            if (!HasPermissions("Service/AddDoc").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var doc = await _context.docs.Where(x => x.serviceID == serviceid).FirstOrDefaultAsync();

            var service = await _context.service.Where(x => x.ID == serviceid).FirstOrDefaultAsync();
            if (service is null)
            {
                Console.WriteLine($"\n\nSERVICE IS NULL \n ID SERWISU: {serviceid}\n\n\n");

            }

            if (doc == null)
            {
                // Tworzenie nowego dokumentu, gdy nie istnieje
                var newDoc = new Docs
                {
                    fullNumber = "",
                    userID = service != null ? service.userID : -1,
                    workerID = User.GetUserID(),
                    addDate = DateTime.UtcNow,
                    sellDate = DateTime.UtcNow,
                    description = "",
                    ownID = 0,
                    docType = 1,
                    payMethod = "Przelew",
                    serviceID = serviceid
                };

                _context.docs.Add(newDoc);
                await _context.SaveChangesAsync();

                // Pobierz nowo utworzony dokument
                doc = newDoc;
            }


            if (doc != null && service.docID == null && service != null)
            {
                var doctype = await _context.docstype.Where(x => x.ID == doc.docType).FirstOrDefaultAsync();

                SetDateTimeKindToUtc(service);
                service.docID = doc.ID;
                service.statusID = 1; // Status 1: W realizacj
                doc.fullNumber = doctype.Short + "/" + doc.ID.ToString() + "/" + DateTime.UtcNow.Year;
                _context.Update(service);
                await _context.SaveChangesAsync();

            }

            var userinfo = await _context.usersinfo.FirstOrDefaultAsync(x => x.userid == service.userID);


            // Lista przedmiotów z dokumentu
            var items = GetDocItems(doc.ID);

            double SumNetto = items.Sum(items => items.allItemsPrice);
            double SumBrutto = items.Sum(items => items.allItemsPriceBR);
            double sumVat = items.Sum(items => items.costVat);

            // Informacje na dokumencie
            var docInfo = await (from d in _context.docs
                                 join u1 in _context.users on d.userID equals u1.id
                                 join u2 in _context.users on d.workerID equals u2.id
                                 where d.ID == doc.ID
                                 select new DocsFullNameModel
                                 {
                                     ID = d.ID,
                                     serviceID = d.serviceID,
                                     fullNumber = d.fullNumber,
                                     userName = u1.displayName,
                                     workerName = u2.displayName,
                                     description = d.description,
                                     addDate = d.addDate,
                                     sellDate = d.sellDate,
                                     Items = items,
                                     costNetto = SumNetto,
                                     costBR = SumBrutto,
                                     costVAT = sumVat,
                                     companyName = userinfo == null ? "" : userinfo.companyName,
                                     companyAddress = userinfo == null ? "" : userinfo.companyAddress,
                                     companyPostCity = userinfo == null ? "" : userinfo.companyPostCity,
                                     companyNIP = userinfo == null ? "" : userinfo.companyNip,
                                     payMethod = d.payMethod

                                 }).FirstOrDefaultAsync();



            // Itemy dla ViewBag.Items - Lista rozwijana przy dodawaniu
            var selector = await (from st in _context.storage
                                  join cat in _context.categories on st.category equals cat.ID
                                  where st.amount > 0
                                  select new StorageSelector
                                  {
                                      id = st.id,
                                      name = st.name,
                                      category = st.category, // assuming this is the category column
                                      categoryName = cat.Name, // assuming this is the category name column
                                      categorySelector = cat.Selector
                                  }).ToListAsync();


            var categories = selector
            .GroupBy(x => new { x.category, x.categoryName })
            .Select(g => g.First()).Where(x => x.categorySelector == "StorageItem")
            .ToList();

            ViewBag.Items = selector;
            ViewBag.Categories = categories;

            return View(docInfo);
        }

        // Lista reklamacji
        public IActionResult Complaints(bool showOld)
        {
            if (!HasPermissions("Service/Complaints").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var model = _context.v_complaints.ToList();

            if (showOld)
            {
                return View(model.Where(x => x.comStatusID == 7));
            }
            else
            {
                return View(model.Where(x => x.comStatusID != 7));
            }
            //return View(model);
        }

        // Szczegóły reklamacji
        public async Task<IActionResult> DetailComplaint(int complaintid, ComplaintsFull model)
        {
            if (!HasPermissions("Service/Complaints").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var complainInfo = await _context.complaints
                .FirstOrDefaultAsync(x => x.ID == complaintid);

            if (complainInfo == null)
            {
                // Obsługa przypadku, gdy skarga nie została znaleziona
                return NotFound();
            }

            var usrID = complainInfo.userID;

            var userInfo = await _context.users
                .FirstOrDefaultAsync(x => x.id == usrID);

            if (userInfo == null)
            {
                // Obsługa przypadku, gdy użytkownik nie został znaleziony
                return NotFound();
            }

            var fullUserInfo = await _context.usersinfo
                .FirstOrDefaultAsync(x => x.userid == usrID);

            var serviceInfo = await _context.service
                .FirstOrDefaultAsync(x => x.ID == complainInfo.serviceID);

            if (serviceInfo == null)
            {
                // Obsługa przypadku, gdy usługa nie została znaleziona
                return NotFound();
            }

            var chat = await (from com in _context.complaintschat
                              join usr2 in _context.usersinfo
                              on com.userID equals usr2.userid
                              join usr in _context.users
                              on usr2.userid equals usr.id
                              where com.complaintID == complaintid
                              select new ComplaintsChat2
                              {
                                  ID = com.ID,
                                  complaintID = com.complaintID,
                                  userID = com.userID,
                                  UserName = usr.displayName,
                                  UserLevel = usr.level,
                                  addDate = com.addDate,
                                  comment = com != null ? com.comment : null,
                              }).OrderBy(x => x.ID).ToListAsync();

            model = new ComplaintsFull
            {
                comID = complaintid,
                serviceID = serviceInfo.ID,
                userID = usrID,
                comAddDate = complainInfo?.addDate,
                comCloseDate = complainInfo?.closeDate,
                comLastDate = complainInfo?.lastDate,
                comComment = complainInfo?.comment,
                userName = userInfo?.displayName,
                userCompName = fullUserInfo?.companyName,
                userContact = fullUserInfo?.contact,
                userContact2 = fullUserInfo?.contact2,
                Chat = chat
            };

            return View(model);
        }

        // Magazyn
        public async Task<IActionResult> Storage(int? categoryid, int? msgType, string? message)
        {
            if (!HasPermissions("Service/Storage").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            ViewBag.MsgType = msgType;
            ViewBag.MsgContent = message; 

            if (msgType != null)
            {
                Console.WriteLine("\n\n\n DODANO POMYŚLNIE");
            }

            ViewBag.Selector = await (from c in _context.categories
                                      where c.Selector == "StorageItem"
                                      select new StorageCat
                                      {
                                          id = c.ID,
                                          categorySelector = c.Name
                                      }).ToListAsync();
          
            var model = await (from s in _context.storage
                               join c in _context.categories
                               on s.category equals c.ID
                               select new StorageCat
                               {
                                   id = s.id,
                                   name = s.name,
                                   category = s.category,
                                   categoryName = c.Name,
                                   categorySelector = c.Selector,
                                   unit = s.unit,
                                   amount = s.amount,
                                   unitPrice = s.unitPrice
                               }).ToListAsync();
            if (categoryid != null)
            {
                var model2 =  model.Where(x => x.category == categoryid).ToList();
                return View(model2);
            }
            
               
            return View(model);
        }

        // Zamówienia
        public async Task<IActionResult> Orders(bool showOld)
        {
            if (!HasPermissions("Service/Orders").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            var model = await _context.v_orders.ToListAsync();

            if (showOld)
            {
                return View(model.Where(x => x.StatusID == 3));
            }
            else
            {
                return View(model.Where(x => x.StatusID != 3));
            }
        }

        // #############################################
        // ############### OPERACJE ################
        // #############################################
       
        // [A] Dodaj pozycje w dokumencie
        [HttpPost, ActionName("AddDocRow")]
        public async Task<IActionResult> AddDocRow(int serviceid, int itid, int amount, int model)
        {
            if (!HasPermissions("Service/AddDoc").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var doc = await _context.docs.Where(x => x.serviceID == serviceid).FirstOrDefaultAsync();
            // Wyciągnięcie ID dokumentu
            var docid = doc?.ID ?? 0;
            var docitem = await _context.docitems.Where(x => x.docID == docid && x.itemID == itid).FirstOrDefaultAsync();
            if (docitem == null) {
                var item = new DocItems
                {
                    docID = docid,
                    itemID = itid,
                    amount = amount
                };
                await _context.docitems.AddAsync(item);
            }
            else
            {
                docitem.amount += amount; // Aktualizuj ilość
                _context.docitems.Update(docitem);
                
            }

            // Aktualizacja magazynu
            var storage = await _context.storage.Where(x=> x.id == itid).FirstOrDefaultAsync();
            storage.amount -= amount;

            _context.storage.Update(storage);

            await _context.SaveChangesAsync();

            //Powrót do strony wywołującej z parametrem
            if (model == null) {
            return RedirectToAction("EditService", new { id = serviceid });
            }
            else
            {
                return RedirectToAction("AddDoc", new { serviceid = serviceid });
            }

        }
       
        // [A] Dodawanie wiadomości na czacie
        [HttpPost,ActionName("AddComment")]
        public async Task<IActionResult> AddComment(int id, string comment)
        {
            if (!HasPermissions("Service/Complaints").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var comView = await _context.complaints.FirstOrDefaultAsync(x => x.ID == id);

            SetDateTimeKindToUtc(comView);
            comView.lastDate = DateTime.UtcNow;
            comView.statusID = 5;

            _context.Update(comView);

            var model = new ComplaintsChat
            {
                addDate = DateTime.UtcNow,
                userID = User.GetUserID(),
                comment = comment,
                complaintID = id
            };
            _context.Add(model);
            _context.SaveChanges();

            return RedirectToAction("DetailComplaint", new { complaintid = id });
        }


        // [A] TWORZENIE DOKUMENTU
        //[HttpPost, ActionName("CompleteDoc")]
        public async Task<IActionResult> CompleteService(int serviceid, int docid)
        {
            if (!HasPermissions("Service/CompleteService").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var service = await _context.service.Where(x => x.ID == serviceid).FirstOrDefaultAsync();
            SetDateTimeKindToUtc(service);
            service.serviceDate = DateTime.UtcNow;
            service.statusID = 3; // Status 3: Zakończony
            _context.Update(service);
            _context.SaveChanges();

            return RedirectToAction("Index","Service");
        }

        // [A] OBSŁUGA EDYCJI
        [HttpPost, ActionName("EditService")]
        public async Task<IActionResult> Edit(int id, Users model)
        {
            if (!HasPermissions("Service/EditService").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            if (id != model.id)
            {
                _logger.LogError($"Wystąpił błąd: {id}!={model.id}");
                return Error();
            }
            _context.Update(model);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // USUWANIE POZYCJI Z DOKUMENTU
        public async Task<IActionResult> DocRowDelete(int docid, int itemid)
        {
            if (!HasPermissions("Service/DocRowDelete").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            // Ustawienie zmiennych
            var docitm = await _context.docitems.Where(x => x.docID == docid && x.itemID == itemid) .FirstOrDefaultAsync();
            var serv = await _context.service.Where(x=> x.docID == docid).FirstOrDefaultAsync();
            
            // Aktualizacja magazynu
            var storage = await _context.storage.Where(x => x.id == itemid).FirstOrDefaultAsync();
            var amount = Int32.Parse(docitm.amount.ToString());
            storage.amount += amount;

           
            // Aktualizacja bazy
            _context.storage.Update(storage);
            _context.docitems.Remove(docitm);
            _context.SaveChanges();

            return RedirectToAction("EditService", new { id = serv.ID });
        }

        [HttpPost, ActionName("AddOrder")]
        public async Task<IActionResult> AddOrder(int id, int amount)
        {
            if (!HasPermissions("Service/Orders").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var itemName = await _context.storage.Where(x=> x.id == id).Select(x=> x.name).FirstOrDefaultAsync();
            var order = new Orders { 
                UserID = User.GetUserID(),
                ItemID = id,
                Amount = amount,
                StatusID = 0
            };

            await _context.orders.AddAsync(order);
            await _context.SaveChangesAsync();

            TempData["UserMessage"] = _helper.ShowModal("Zamówienie złożone", $"{itemName} x {amount}");

            return RedirectToAction("Storage");

        }
    }
}
