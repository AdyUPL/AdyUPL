﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Serwis_Aut.Context;
using Serwis_Aut.Models;
using Serwis_Aut.Helpers;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;
using System.Security.Policy;
using NuGet.Protocol;


namespace Serwis_Aut.Controllers
{
    public class ClientPortalController : Controller
    {
        private readonly PermissionHelper _permissionHelper;
        private readonly myAppContext _context;



        public ClientPortalController( PermissionHelper permissionHelper, myAppContext context)
        {
            _permissionHelper = permissionHelper;
            _context = context;
        }
        // ############################## INNE #############################
        // Sprawdzanie uprawnień
        private async Task<bool> HasPermissions(string pageName)
        {
            int userLevel = User.GetUserLevel();
            bool perm = await _permissionHelper.HasPermissionAsync(userLevel, pageName);

            return perm || userLevel == -1;

        }
        public void SetDateTimeKindToUtc(object entity)
        {
            var properties = entity.GetType().GetProperties()
            .Where(p => p.PropertyType == typeof(DateTime) || p.PropertyType == typeof(DateTime?));

            foreach (var property in properties)
            {
                if (property.PropertyType == typeof(DateTime))
                {
                    var date = (DateTime)property.GetValue(entity);
                    if (date.Kind == DateTimeKind.Unspecified)
                    {
                        property.SetValue(entity, DateTime.SpecifyKind(date, DateTimeKind.Utc));
                    }
                }
                else if (property.PropertyType == typeof(DateTime?))
                    {
                        var date = (DateTime?)property.GetValue(entity);
                        if (date.HasValue && date.Value.Kind == DateTimeKind.Unspecified)
                        {
                            property.SetValue(entity, (DateTime?)DateTime.SpecifyKind(date.Value, DateTimeKind.Utc));
                        }
                    }
            }
        }

        // ######################################################################
        // ############################## WYŚWIETLANIE #############################

        // [W] Główna
        public IActionResult Index()
        {
            if (!HasPermissions("ClientPortal/Index").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            return View();

        }

        // [W] Sklep
        public IActionResult Shop()
        {

            if (!HasPermissions("ClientPortal/Shop").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            return View();

        }

        // [W] Serwis
        public async Task<IActionResult> Service()
        {

            var userid = User.GetUserID();

            if (!HasPermissions("ClientPortal/Service").Result || userid == 0)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            //Konstruowanie widoku
            var userServiceRequests = await (from s in _context.service
                                             join c in _context.cars on s.carID equals c.ID
                                             join co in _context.complaints on s.ID equals co.serviceID into coGroup
                                             from co in coGroup.DefaultIfEmpty()
                                             join st in _context.status on s.statusID equals st.id
                                             join d in _context.docs on s.docID equals d.ID into docsGroup
                                             from d in docsGroup.DefaultIfEmpty()
                                             where s.userID == userid
                                             select new ServiceUserViewModel
                                             {
                                                 id = s.ID,
                                                 auto = c.brand + " " + c.model,
                                                 userID = s.userID,
                                                 opis = s.description,
                                                 status = st.name,
                                                 addDate = s.addDate,
                                                 docID = d != null ? d.ID : (int?)null,
                                                 docFullName = d != null ? d.fullNumber : null,
                                                 serviceDate = s.serviceDate,
                                                 workerID = s != null ? s.workerID :(int?)null ,
                                                 complaintID = co != null ? co.ID:(int?)null,
                                                 complaintStatus = co != null ? co.statusID : (int?)null
                                             }).ToListAsync();



            return View(userServiceRequests);

        }

        // [W] Dodaj Serwis
        public IActionResult AddService()
        {

            if (!HasPermissions("ClientPortal/AddService").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            var userid = User.GetUserID();
            var myCars = _context.cars.Where(s => s.userID == userid && s.deleted==false)
                                                       .ToList();
            ViewBag.UserLevels = myCars.Select(ul => new SelectListItem
            {
                Value = ul.ID.ToString(),
                Text = ul.brand + " " + ul.model + " | " + ul.registerplate,
            }).ToList();

            return View();

        }

        // [W] Pokaż dokument
        public async Task<IActionResult> DocumentView(int id)
        {
            try
            {
                // Pobranie Id Usera z dokumentu
                var userid = await _context.docs.FirstOrDefaultAsync(x => x.ID == id);
                int? useridint = userid.userID;

                // Pobranie informacji o userze
                var userinfo = await _context.usersinfo.FirstOrDefaultAsync(x => x.userid == useridint);


                if (!await HasPermissions("Shared/ShowDocs") || (useridint != User.GetUserID() && User.GetUserLevel() == 1 ))
                {
                    return RedirectToAction("AccessDenied", "Home");
                }

                Console.WriteLine($"DocID: {id}");
                if (id == 0)
                {
                    return BadRequest("Document ID cannot be 0(zero)");
                }

                // Lista przedmiotów z dokumentu
                var items = await (from i in _context.docitems
                                   join st in _context.storage on i.itemID equals st.id
                                   where i.docID==id
                                   select new DocItemsList
                                   {
                                       ID = i.ID,
                                       docID = i.docID,
                                       itemID = i.itemID,
                                       amount = i.amount,
                                       itemName = st.name,
                                       itemUnit = st.unit,
                                       itemUnitPrice = st.unitPrice, // cena za 1 jm
                                       itemUnitPriceBR= Math.Round(st.unitPrice*1.23,2), // cena brutto za 1 jm
                                       allItemsPrice = st.unitPrice*i.amount, // suma  netto 
                                       allItemsPriceBR= Math.Round(st.unitPrice*i.amount*1.23,2), //suma brutto
                                       costVat= Math.Round(((st.unitPrice * 1.23) - st.unitPrice) * i.amount,2) // suma br - suma netto
                                       
                                   }).ToListAsync();

                double SumNetto = items.Sum(items => items.allItemsPrice);
                double SumBrutto = items.Sum(items => items.allItemsPriceBR);
                double sumVat = items.Sum(items=> items.costVat);

                // Informacje na dokumencie
                var docInfo = await (from d in _context.docs
                                     join u1 in _context.users on d.userID equals u1.id
                                     join u2 in _context.users on d.workerID equals u2.id
                                     where d.ID == id
                                     select new DocsFullNameModel
                                     {
                                         ID = d.ID,
                                         fullNumber = d.fullNumber,
                                         userName = u1.displayName,
                                         workerName = u2.displayName,
                                         description = d.description,
                                         addDate = d.addDate,
                                         sellDate = d.sellDate,
                                         Items = items,
                                         costNetto = SumNetto,
                                         costBR = SumBrutto,
                                         costVAT = sumVat,
                                         companyName = userinfo.companyName,
                                         companyAddress = userinfo.companyAddress,
                                         companyPostCity = userinfo.companyPostCity,
                                         companyNIP = userinfo.companyNip,
                                         payMethod = d.payMethod

                                     }).FirstOrDefaultAsync();

                if (docInfo == null)
                {
                    return BadRequest("DocInfo is null");
                }

                return View("~/Views/Shared/DocumentView.cshtml",docInfo);
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"An error occurred: {ex.Message}");
                return View("Error", new ErrorViewModel
                {
                    RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier,
                    Message = ex.Message
                });
            }
        }

        // [W] Moje auta
        public async Task<IActionResult> Cars()
        {
            var userid = User.GetUserID();

            if (!HasPermissions("ClientPortal/Cars").Result || userid == 0)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            var userServiceRequests = await _context.cars
                                                       .Where(s => s.userID == userid && s.deleted==false)
                                                       .ToListAsync();

            return View(userServiceRequests);

        }

        // [W] Dodawanie auta
        public IActionResult AddCar()
        {
            if (!HasPermissions("ClientPortal/AddCar").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            return View();

        }


        // [W] Płatności
        public IActionResult Payments()
        {

            if (!HasPermissions("ClientPortal/Payments").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            return View();

        }


        // ######################################################################
        // ############################## DODAWANIE #############################


        // [D] Rejestracja auta
        [HttpPost, ActionName("AddCar")]
        public async Task<IActionResult> AddCar(Cars car)
        {
            if (!HasPermissions("ClientPortal/AddCar").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            car.userID = User.GetUserID();
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(car); // Dodaj użytkownika do kontekstu
                    await _context.SaveChangesAsync(); // Zapisz zmiany do bazy danych

                    return RedirectToAction("Cars","ClientPortal"); // Przekieruj na stronę główną
                }
                catch (Exception ex)
                {
                    // Obsłużanie ewentualnych błędów
                    Console.WriteLine($"\nWystąpił błąd podczas dodawania użytkownika: {ex.Message}\n"); // Przekazanie szczegółów błędu do widoku
                    return View("Error");
                }
            }
            else
            {
                // Sprawdzenie błędów ModelState i wypisanie ich do konsoli
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var error in modelState.Errors)
                    {
                        Console.WriteLine($"Błąd: {error.ErrorMessage}");
                        if (error.Exception != null)
                        {
                            Console.WriteLine($"Wyjątek: {error.Exception.Message}");
                        }
                    }
                }
                return RedirectToAction("AddCar", car);
            }
        }


        // [D] Nowe zgłoszenie
        [HttpPost, ActionName("AddService")]
        public async Task<IActionResult> AddService(Service item) {
            if (!HasPermissions("ClientPortal/AddService").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            item.userID = User.GetUserID();

            item.addDate = DateTime.UtcNow;

            item.statusID = 0;

            Console.WriteLine("DATA: " + item.addDate.ToString()+ "\n A NORMALNIE: "+DateTime.Now.ToString());

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(item); // Dodaj użytkownika do kontekstu
                    await _context.SaveChangesAsync(); // Zapisz zmiany do bazy danych

                    return RedirectToAction("Service", "ClientPortal"); // Przekieruj na stronę główną
                }
                catch (Exception ex)
                {
                    // Obsłużanie ewentualnych błędów
                    Console.WriteLine($"\nWystąpił błąd podczas dodawania: {ex.Message}\n"); // Przekazanie szczegółów błędu do widoku
                    return View("Error","Shared");
                }
            }
            else
            {
                // Sprawdzenie błędów ModelState i wypisanie ich do konsoli
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var error in modelState.Errors)
                    {
                        Console.WriteLine($"Błąd: {error.ErrorMessage}");
                        if (error.Exception != null)
                        {
                            Console.WriteLine($"Wyjątek: {error.Exception.Message}");
                        }
                    }
                }
                return RedirectToAction("Service", item);
            }
        }

        // [W] Reklamacja

        public async Task<IActionResult> Complaint(int complainid, ComplaintsFull model)
        {
            var complainInfo = await _context.complaints
                .FirstOrDefaultAsync(x => x.ID == complainid);

            if (complainInfo == null)
            {
                // Obsługa przypadku, gdy skarga nie została znaleziona
                return NotFound();
            }

            var usrID = complainInfo.userID;
    
            var userInfo = await _context.users
                .FirstOrDefaultAsync(x => x.id == usrID);

            if (userInfo == null)
            {
                // Obsługa przypadku, gdy użytkownik nie został znaleziony
                return NotFound();
            }

            var fullUserInfo = await _context.usersinfo
                .FirstOrDefaultAsync(x => x.userid == usrID);

            var serviceInfo = await _context.service
                .FirstOrDefaultAsync(x => x.ID == complainInfo.serviceID);

            if (serviceInfo == null)
            {
                // Obsługa przypadku, gdy usługa nie została znaleziona
                return NotFound();
            }

            var chat = await (from com in _context.complaintschat
                              join usr2 in _context.usersinfo
                              on com.userID equals usr2.userid
                              join usr in _context.users
                              on usr2.userid equals usr.id
                              where com.complaintID == complainid
                              select new ComplaintsChat2
                              {
                                  ID = com.ID,
                                  complaintID = com.complaintID,
                                  userID = com.userID,
                                  UserName = usr.displayName,
                                  UserLevel = usr.level,
                                  addDate = com.addDate,
                                  comment = com != null ? com.comment : null,
                              }).OrderBy(x=> x.ID).ToListAsync();

            model = new ComplaintsFull
            {
                comID = complainid,
                serviceID = serviceInfo.ID,
                userID = usrID,
                comAddDate = complainInfo?.addDate,
                comCloseDate = complainInfo?.closeDate,
                comLastDate = complainInfo?.lastDate,
                comComment = complainInfo?.comment ,
                userName = userInfo?.displayName,
                userCompName = fullUserInfo?.companyName,
                userContact = fullUserInfo?.contact,
                userContact2 = fullUserInfo?.contact2,
                Chat = chat
            };

            return View(model);
        }


        // [W] Nowa reklamacja
        public async Task<IActionResult> NewComplaint(int serviceid, Service model)
        {
            model = await _context.service.Where(x => x.ID == serviceid).FirstOrDefaultAsync();
            if (model == null)
            {
                return NotFound();
            }
            ViewBag.Complaint = new Complaints();
            return View(model);
         }
        // [D] Nowa reklamacja
        [HttpPost, ActionName("NewComplaint")]
        public async Task<IActionResult> NewComplaint(string comment, int serviceid)
        {
            var model = new Complaints
            {
                userID = User.GetUserID(),
                serviceID = serviceid,
                comment = comment,
                addDate = DateTime.UtcNow,
                lastDate = DateTime.UtcNow,
                statusID = 4

            };
            SetDateTimeKindToUtc(model);
            _context.Add(model);
            _context.SaveChanges();
            return RedirectToAction("Service", "ClientPortal");
        }

        public async Task<IActionResult> AddComment(int id, string comment)
        {
            
            var comView = await _context.complaints.FirstOrDefaultAsync(x => x.ID == id);
            
                SetDateTimeKindToUtc(comView);
                comView.lastDate = DateTime.UtcNow;
                comView.statusID = 6;

                _context.Update(comView);
            
            var model = new ComplaintsChat
            {
                addDate = DateTime.UtcNow,
                userID = User.GetUserID(),
                comment = comment,
                complaintID = id
            };
            _context.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Complaint",new {complainid = id});
        }

        // ######################################################################
        // ############################## EDYCJA ##############################
        // [A] Edycja auta

        // ######################################################################

        // ############################## USUWANIE ##############################
        // [U] Usuwanie auta
        [HttpPost, ActionName("DeleteCar")]
        public async Task<IActionResult> Edit(int id)
        {
            if (!HasPermissions("ClientPortal/DeleteCar").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var car = await _context.cars.FindAsync(id);
            if (id != car.ID)
            {
                Console.WriteLine("BŁĄD: Przekazane ID różni się od ID samochodu");
                return RedirectToAction("AddCar", car);
            }
            // Oznacz jako usunięte - Nie usuwam, ponieważ w systemie mogą być faktury na to auto lub zdażenia serwisowe
            car.deleted = true;
            _context.Attach(car).Property(x => x.deleted).IsModified = true;
            await _context.SaveChangesAsync();
            return RedirectToAction("Cars", "ClientPortal");
        }
        // ######################################################################



    }
}

