﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Serwis_Aut.Context;
using Serwis_Aut.Models;
using Serwis_Aut.Helpers;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Serwis_Aut.Controllers
{
    public class UsersController : Controller
    {
        private readonly myAppContext _context;
        private readonly ILogger<UsersController> _logger;
        private readonly IConfiguration _configuration;
        private readonly PermissionHelper _permissionHelper;

        public UsersController(myAppContext context, ILogger<UsersController> logger, IConfiguration configuration, PermissionHelper permissionHelper)
        {
            _configuration = configuration;
            _logger = logger;
            _context = context;
            _permissionHelper = permissionHelper;
        }

        // Sprawdzanie uprawnień
        private async Task<bool> HasPermissions(string pageName)
        {
            int userLevel = User.GetUserLevel();
            bool perm = await _permissionHelper.HasPermissionAsync(userLevel, pageName);

                return perm || userLevel == -1;

        }

        // WYŚWIETLEWNIE STRONY
        public async Task<IActionResult> Index()
        {
            if (!HasPermissions("User/Index").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var users = await _context.users.ToListAsync();
            var userLevels = await _context.userslevels.ToListAsync();
            var userLevelDict = userLevels.ToDictionary(ul => ul.id, ul => ul.Name);

            var viewModel = users.Select(user => new UserViewModel
            {
                Id = user.id,
                Name = user.displayName,
                Login = user.login,
                Password = user.password,
                Level = user.level,
                LevelName = userLevelDict.ContainsKey(user.level) ? userLevelDict[user.level] : "Unknown"
            }).ToList();

            return View(viewModel);

            //return View(await _context.users.ToListAsync());

        }

        // WYŚWIETLENIE STRONY DODAWANIA
        public async Task<IActionResult> AddUser()
        {
            if (!HasPermissions("User/AddUser").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var userLevels = await _context.userslevels.ToListAsync();
            ViewBag.UserLevels = userLevels.Select(ul => new SelectListItem
            {
                Value = ul.id.ToString(),
                Text = ul.Name
            }).ToList();

            return View();
        }

        // OBSŁUGA DODAWANIA
        [Authorize]
        [HttpPost, ActionName("AddUser")]
        public async Task<IActionResult> AddUser(Users model)
        {
            // Sprawdzenie uprawnień przed wykonaniem logiki biznesowej
            if (!await HasPermissions("User/AddUser"))
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(model); // Dodaj użytkownika do kontekstu
                    await _context.SaveChangesAsync(); // Zapisz zmiany do bazy danych
                    return RedirectToAction("Index"); // Przekieruj na stronę główną
                }
                catch (Exception ex)
                {
                    // Obsłużanie ewentualnych błędów
                    _logger.LogError($"Wystąpił błąd podczas dodawania użytkownika: {ex.Message}");
                    ViewBag.ErrorMessage = $"Wystąpił błąd podczas dodawania użytkownika: {ex.Message}"; // Przekazanie szczegółów błędu do widoku
                    return View("Error");
                }
            }
            else
            {
                // Zwróć widok formularza z błędami
                return View("AddUser", model);
            }
        }





        public IActionResult Error()
        {
            var errorViewModel = new ErrorViewModel();
            // Ustawianie właściwości errorViewModel, jeśli to konieczne
            return View(errorViewModel);
        }


        // WYŚWIETLENIE STRONY DO EDYCJI
        public async Task<IActionResult> EditUser(int? id)
        {
            if (!HasPermissions("User/EditUser").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            if (id != null)
            {
                var user = await _context.users.FindAsync(id);
                // Pobranie dostępnych poziomów użytkowników, jeśli model nie jest prawidłowy
                var userLevels = await _context.userslevels.ToListAsync();
                ViewBag.UserLevels = userLevels.Select(ul => new SelectListItem
                {
                    Value = ul.id.ToString(),
                    Text = ul.Name
                }).ToList();

                return View(user);
            }
            else
            {
                return Error();
            }


        }


        // OBSŁUGA EDYCJI
        [HttpPost, ActionName("EditUser")]
        public async Task<IActionResult> Edit(int id, Users model)
        {
            if (!HasPermissions("User/EditUser").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            if (id != model.id)
            {
                _logger.LogError($"Wystąpił błąd: {id}!={model.id}");
                return Error();
            }
            _context.Update(model);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // OBSŁUGA USUWANIA
        [HttpPost, ActionName("DeleteUser")]
        public async Task<IActionResult> Delete(int id)
        {
            if (!HasPermissions("User/DeleteUser").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            var user = await _context.users.FindAsync(id);
            
            if (user == null)
            {
                _logger.LogError($"Użytkownik o id {id} nie istnieje.");
                return Error();
            }
            
            _context.Remove(user);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

    }
}

