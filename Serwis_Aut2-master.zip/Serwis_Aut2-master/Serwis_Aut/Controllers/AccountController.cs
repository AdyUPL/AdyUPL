﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication;
using Serwis_Aut.Context;
using System.Security.Claims;
using Serwis_Aut.Helpers;
using Serwis_Aut.Models;


namespace Serwis_Aut.Controllers
{
    public class AccountController : Controller
    {
        private readonly myAppContext _context;
        private readonly PermissionHelper _permissionHelper;
        private readonly ContentHelper _helper;

        public AccountController(myAppContext context,PermissionHelper permissionHelper, ContentHelper helper)
        {
            _context = context;
            _permissionHelper = permissionHelper;
            _helper = helper;
        }

        private async Task<bool> HasPermissions(string pageName)
        {
            int userLevel = User.GetUserLevel();
            bool perm = await _permissionHelper.HasPermissionAsync(userLevel, pageName);

            return perm || userLevel == -1;

        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string login, string password)
        {
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError(string.Empty, "Login i hasło są wymagane.");
            }

            if (ModelState.IsValid)
            {
                var user = await _context.users.SingleOrDefaultAsync(u => u.login == login && u.password == password);
                if (user != null)
                {
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, user.login),
                        new Claim("UserID", user.id.ToString()),
                        new Claim("UserLevel",user.level.ToString()),
                        new Claim("DisplayName",user.displayName.ToString())
                    };

                    var claimsIdentity = new ClaimsIdentity(claims, "SerwisAut");
                    var authProperties = new AuthenticationProperties
                    {
                        IsPersistent = true, // ciasteczko przetrwa zamknięcie przeglądarki
                        ExpiresUtc = DateTimeOffset.UtcNow.AddHours(1) // czas życia ciasteczka
                };

                    await HttpContext.SignInAsync("SerwisAut", new ClaimsPrincipal(claimsIdentity), authProperties);

                    return RedirectToAction("Index", "Home");
                }
                ModelState.AddModelError(string.Empty, "Nieprawidłowy login lub hasło."); // Błędne login lub hasło
            }


            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {

            await HttpContext.SignOutAsync("SerwisAut");
            Response.Cookies.Delete(".AspNetCore.Cookies");

            return RedirectToAction("Index", "Home");
        }

        // [W] Ekran z informacjami
        public async Task<IActionResult> UserInfo(int? id)
        {
            if (!HasPermissions("Account/EditUserInfo").Result || id != User.GetUserID() )
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            var infomodel = await (from i in _context.usersinfo
                                   join u in _context.users on i.userid equals u.id
                                   where i.userid==id
                                   select new UserInfoModel
                                   {
                                       userid = i.userid,
                                       displayName = u.displayName,
                                       companyName = i.companyName,
                                       companyAddress = i.companyAddress,
                                       companyNip = i.companyNip,
                                       companyPostCity = i.companyPostCity,
                                       contact = i.contact,
                                       contact2 = i.contact2,

                                   }).FirstOrDefaultAsync();

            return View(infomodel);
        }

        // [E] Aktualizacja informacji
        [HttpPost, ActionName("UserInfoEdit")]
        public async Task<IActionResult> UserInfoEdit(int id, UserInfoModel model)
        {
            if (!HasPermissions("Account/EditUserInfo").Result || id != User.GetUserID())
            {
                return RedirectToAction("AccessDenied", "Home");
            }



            if (!ModelState.IsValid)
            {
                Console.WriteLine("\n-----------Model is VALID-----------\n");
                return View(model);
            }

            var userInfo = await _context.usersinfo.FirstOrDefaultAsync(x => x.userid == id);
            if (userInfo == null)
            {
                Console.WriteLine("\n-----------User info not found-----------\n");
                return NotFound("User info not found");
            }

            var user = await _context.users.FirstOrDefaultAsync(x => x.id == id);
            if (user == null)
            {
                Console.WriteLine("\n-----------User not found-----------\n");
                return NotFound("User not found");
            }

            userInfo.companyAddress = model.companyAddress;
            userInfo.companyNip = model.companyNip;
            userInfo.companyName = model.companyName;
            userInfo.companyPostCity = model.companyPostCity;
            userInfo.contact = model.contact;
            userInfo.contact2 = model.contact2;

            user.displayName = model.displayName;

            try
            {
                _context.Update(userInfo);
                _context.Update(user);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine($"\n\n BŁĄD: {ex.Message}");
                return View("UserInfo",model);
            }

            var claimsIdentity = User.Identity as ClaimsIdentity;
            if (claimsIdentity != null)
            {
                // Usuń istniejącą nazwę
                var existingClaim = claimsIdentity.FindFirst("DisplayName");
                if (existingClaim != null)
                {
                    claimsIdentity.RemoveClaim(existingClaim);
                }
                // Dodaj nową nazwę
                claimsIdentity.AddClaim(new Claim("DisplayName", user.displayName));

                // Aktualizuj obiekt ClaimsPrincipal
                await HttpContext.SignInAsync(new ClaimsPrincipal(claimsIdentity));
            }

            return View("UserInfo", model);
        }

        [HttpPost,ActionName("ChangePassword")]
        public async Task<IActionResult> ChangePassword(int id,string? OldPass, string? NewPass, string? NewPass2,string returnUrl)
        {
           var user = await _context.users.FirstOrDefaultAsync(x=>x.id== id);
           var u_oldPass = user.password;
           
           if ( OldPass  == u_oldPass && NewPass == NewPass2)
           {
               TempData["UserMessage"] = _helper.ShowModal("Sukces!", $"Twoje hasło zostało zmienione");
               user.password = NewPass2;
               _context.users.Update(user);
               _context.SaveChanges();
           }
           else
           {
               TempData["UserMessage"] = _helper.ShowModal("Błąd!", $"Hasła nie pasują");
           }

           return Redirect(returnUrl);
        }


    }
}
