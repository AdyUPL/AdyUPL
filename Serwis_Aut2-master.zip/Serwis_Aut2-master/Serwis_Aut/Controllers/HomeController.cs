using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Serwis_Aut.Context;
using Serwis_Aut.Helpers;
using Serwis_Aut.Models;
using System.Diagnostics;

namespace Serwis_Aut.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly PermissionHelper _permissionHelper;
        private readonly ContentHelper _helper;
        private readonly myAppContext _context;

        public HomeController(ILogger<HomeController> logger, PermissionHelper permissionHelper, myAppContext context, ContentHelper helper)
        {
            _logger = logger;
            _permissionHelper = permissionHelper;
            _context = context;
            _helper = helper;
        }

        // ############################## INNE #############################
        // Sprawdzanie uprawnie�
        private async Task<bool> HasPermissions(string pageName)
        {
            int userLevel = User.GetUserLevel();
            bool perm = await _permissionHelper.HasPermissionAsync(userLevel, pageName);

            return perm || userLevel == -1;

        }

        // ######################################################################
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult AccessDenied()
        {
            return View();
        }


        // WY�WIETLENIE STRONY DO EDYCJI
        public async Task<IActionResult> EditUser(int? id)
        {
            if (!HasPermissions("User/EditUser").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            if (id != null)
            {
                var user = await _context.users.FindAsync(id);
                // Pobranie dost�pnych poziom�w u�ytkownik�w, je�li model nie jest prawid�owy

                return View(user);
            }
            else
            {
                return Error();
            }


        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        // [W] Poka� dokument
        public async Task<IActionResult> OtherDocumentView(int id,string type)
        {
            ViewBag.DocType=type;
            var model = await _context.v_orders.FirstOrDefaultAsync(x => x.ID == id);
            


            return View("~/Views/Shared/OtherDocumentView.cshtml", model);

        }

        public async Task<IActionResult> Search(int id, string returnurl)
        {
            //var stinfo =  _context.service.Where(x=> x.ID == id).Select(x => x.statusID).FirstOrDefaultAsync();

            var info = await (from s in _context.service
                              join st in _context.status
                              on s.statusID equals st.id
                              where s.ID == id
                              select st.name).FirstOrDefaultAsync();
            
            if (info != null) // Je�li znajdzie status
            {
                TempData["UserMessage"] = _helper.ShowModal("Status twojego zam�wienia",$"{info}<br> Zapraszamy po odbi�r auta");
            }
            else
            {
                TempData["UserMessage"] = _helper.ShowModal("B��d", $"Nie odnaleziono zg�oszenia o podanym numerze");
            }
            return Redirect(returnurl);
        }
    }
}
