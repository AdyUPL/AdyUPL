using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Serwis_Aut.Context;
using Serwis_Aut.Helpers;
using Serwis_Aut.Models;
using System.Diagnostics;
using System.Globalization;
using System.Xml.Linq;

namespace Serwis_Aut.Controllers
{
    public class StorageController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly PermissionHelper _permissionHelper;
        private readonly ContentHelper _helper;
        private readonly myAppContext _context;

        public StorageController(ILogger<HomeController> logger, PermissionHelper permissionHelper, myAppContext context, ContentHelper helper)
        {
            _logger = logger;
            _permissionHelper = permissionHelper;
            _context = context;
            _helper = helper;
        }

        // ############################## INNE #############################
        // Sprawdzanie uprawnie�
        private async Task<bool> HasPermissions(string pageName)
        {
            int userLevel = User.GetUserLevel();
            bool perm = await _permissionHelper.HasPermissionAsync(userLevel, pageName);

            return perm || userLevel == -1;

        }

        // ######################################################################

        // ############################## WY�WIETLANIE #############################

        // [Widok] Magazyn

        public async Task<IActionResult> Storage(int? categoryid)
        {
            if (!HasPermissions("Storage/Storage").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var categories = await _context.categories.Where(x => x.Selector == "StorageItem").GroupBy(c => c.Name).Select(x => new { x.First().ID, x.First().Name}).ToListAsync();

            ViewBag.Categories = categories;

            var model = await (from s in _context.storage
                               join st in _context.categories
                               on s.category equals st.ID
                               select new StorageCat
                               {
                                   id = s.id,
                                   name = s.name,
                                   category = s.category,
                                   categoryName = st.Name,
                                   amount = s.amount,
                                   unit = s.unit,
                                   unitPrice = s.unitPrice,
                                   categorySelector = st.Selector
                               }).ToListAsync();
            if (categoryid != null)
            {
                return View(model.Where(x=>x.category== categoryid).OrderBy(x => x.id));
            }
            else
            {
                return View(model.OrderBy(x => x.id));
            }
          
        }

        // [Widok] Kategorie

        public async Task<IActionResult> Categories()
        {
            if (!HasPermissions("Storage/Category").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var categories = await _context.categories.Where(x=> x.Selector == "StorageItem").OrderBy(x=> x.ID).ToListAsync();

                return View(categories);

        }

        // [Widok] Zam�wienia

        public async Task<IActionResult> Orders(bool showOld,List<OrdersView> model)
        {
            if (!HasPermissions("Storage/Orders").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            if (showOld)
            {
                model = await _context.v_orders.Where(x => x.StatusID == 3).ToListAsync();
            }
            else
            {
                model = await _context.v_orders.Where(x => x.StatusID == 0).ToListAsync();
            }
           
            return View(model);
        }

        // [Widok] Poka� dokument
        public async Task<IActionResult> DocumentShow(int id, string type)
        {

            return RedirectToAction("OtherDocumentView","Home",new { id = id, type = type });
        }
        // ######################################################################

        // ############################## DODAWANIE #############################

        // [Dod] Dodawanie przedmiotu
        public async Task<IActionResult> AddItem(string name, int amount,int category, string unit, string unitPrice)
        {
            if (!HasPermissions("Storage/StorageEdit").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var model = new Storage
            {
                name = name,
                amount = amount,
                category= category,
                unit = unit,
                unitPrice = double.Parse(unitPrice, CultureInfo.InvariantCulture)
            };

            TempData["UserMessage"] = _helper.ShowModal("Sukces!", $"Dodano nowy towar: {name}");
            _context.storage.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Storage");
        }

        // [Dod] Dodawanie przedmiotu
        public async Task<IActionResult> AddCategory(string name)
        {
            if (!HasPermissions("Storage/CategoryEdit").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var model = new Categories
            {
                Name = name,
                Selector = "StorageItem"
            };
            TempData["UserMessage"] = _helper.ShowModal("Sukces!","Kategoria dodana.");

            _context.categories.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Categories");
        }


        // ######################################################################

        // ############################## EDYCJA #############################

        // [Akt] Edycja przedmiotu
        [HttpPost,ActionName("EditItem")]
        public async Task<IActionResult> EditItem (int id, string name, int amount, string unit, string unitPrice )
        {
            if (!HasPermissions("Storage/StorageEdit").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var model = await _context.storage.Where(x=> x.id == id).FirstOrDefaultAsync();

            model.name=name;
            model.amount=amount;
            model.unit=unit;
            model.unitPrice = double.Parse(unitPrice, CultureInfo.InvariantCulture);
            _context.SaveChanges();
            TempData["UserMessage"] = _helper.ShowModal("Edycja zako�czona pomy�lnie", $"Towar \"{name}\" zaktualizowany");

            return RedirectToAction("Storage");
        }
        [HttpPost, ActionName("EditCategory")]

        public async Task<IActionResult> EditCategory(int id, string name)
        {
            if (!HasPermissions("Storage/CategoryEdit").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var model = await _context.categories.Where(x => x.ID == id).FirstOrDefaultAsync();
            model.Name = name;
           
            _context.Update(model);
            _context.SaveChanges();
            TempData["UserMessage"] = _helper.ShowModal("Sukces!", $"Zapisano pomy�lnie");
            return RedirectToAction("Categories");
        }

        public async Task<IActionResult> CompleteOrder(int id, string returnurl)
        {
            if (!HasPermissions("Storage/Orders").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }

            // Szukanie zam�wienia
            var order = await _context.orders.FirstOrDefaultAsync(x=> x.ID == id);
            // Konwersja ilo�ci na int
            if (order.Amount == null)
            {
                order.Amount = 0;
            }
            int amount = Int32.Parse(order.Amount.ToString());
            // Szukanie itemu w magazynie
            var storage = await _context.storage.FirstOrDefaultAsync(x => x.id == order.ItemID);
            // Zwi�kszenie stanu magazynowego
            storage.amount += amount;
            // Zmiana statusu zam�wienia
            order.StatusID = 3;
            // Zapis do bazy
            _context.orders.Update(order);
            _context.storage.Update(storage);
            _context.SaveChanges();

            TempData["UserMessage"] = _helper.ShowModal("Sukces!", $"Zam�wienie nr {id} zrealizowane.<br> Towar automatycznie zosta� zarejestrowany w magazynie");

            return Redirect(returnurl);
        }
        // ######################################################################

        // ############################## USUWANIE #############################
        public async Task<IActionResult> DelCategory(int id,string returnurl)
        {
            if (!HasPermissions("Storage/CategoryEdit").Result)
            {
                return RedirectToAction("AccessDenied", "Home");
            }
            var model = await _context.categories.Where(x => x.ID == id).FirstOrDefaultAsync();
            var name = model?.Name;
            _context.Remove(model);
            _context.SaveChanges();
            TempData["UserMessage"] = _helper.ShowModal("Sukces!", $"Kategoria \"{name}\" zosta�a usuni�ta");
            return Redirect(returnurl);
        }

    }
}
